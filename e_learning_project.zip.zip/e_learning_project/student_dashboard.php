<?php
session_start();
require 'db_connect.php'; // Aapki database connection file

// Login ke baad session mein student_id set honi chahiye. Abhi ke liye hum 1 maan lete hain.
// In real app: $_SESSION['student_id'] = $userId;
if (!isset($_SESSION['student_id'])) {
    $_SESSION['student_id'] = 1; // Example student_id
}
$student_id = $_SESSION['student_id'];

// Submitted assignments ko database se laayein
$query = "SELECT assignment_name, file_name, upload_date FROM submitted_assignments WHERE student_id = $student_id ORDER BY upload_date DESC";
$result = mysqli_query($conn, $query);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF--8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <!-- Aapki style.css file ko link karein -->
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="navbar">
        <div class="logo">My Dashboard</div>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>

    <div class="container">
        <div class="dashboard-card">
            <h2>My Dashboard</h2>
            <p><strong>Your Role:</strong> Student</p>
            <p><strong>My Courses:</strong> Software Testing - BCA Semester 3</p>

            <?php
            // Success/Error message dikhayein
            if (isset($_GET['status'])) {
                if ($_GET['status'] == 'success') echo '<div class="message success">File uploaded successfully!</div>';
                else echo '<div class="message error">Something went wrong. Please try again.</div>';
            }
            ?>

            <!-- Assignment Upload Section -->
            <h3>Upload New Assignment</h3>
            <form action="upload.php" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="assignment_name">Select Assignment:</label>
                    <select name="assignment_name" id="assignment_name" required>
                        <option value="">--Select an Assignment--</option>
                        <option value="Unit 1 - Introduction to Testing">Unit 1 - Introduction to Testing</option>
                        <option value="Unit 2 - STLC Models">Unit 2 - STLC Models</option>
                        <option value="Practical - Test Case Design">Practical - Test Case Design</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="assignmentFile">Select file to upload:</label>
                    <input type="file" name="assignmentFile" id="assignmentFile" required>
                </div>
                <button type="submit" class="upload-btn">Upload Assignment</button>
            </form>

            <!-- Submitted Assignments Section -->
            <h3>My Submitted Assignments</h3>
            <table class="assignments-table">
                <thead>
                    <tr>
                        <th>Assignment Name</th>
                        <th>File Name</th>
                        <th>Submission Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (mysqli_num_rows($result) > 0) {
                        while($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['assignment_name']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['file_name']) . "</td>";
                            echo "<td>" . date('d M Y, h:i A', strtotime($row['upload_date'])) . "</td>";
                            echo "<td><a href='uploads/" . htmlspecialchars($row['file_name']) . "' download>Download</a></td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4'>No assignments submitted yet.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
            
        </div>
    </div>

</body>
</html>
<?php
mysqli_close($conn);
?>