<?php
// Aapke AWebServer app me jo address hai, woh yahan daalein
$servername = "192.168.1.2:3306"; 

$username = "root";
$password = "root";
$dbname = "silveroak_e_learning_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start session on every page that includes this file
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>