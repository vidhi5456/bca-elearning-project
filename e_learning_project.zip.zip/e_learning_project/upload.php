<?php
session_start();
require 'db_connect.php'; // Aapki database connection file

// Check if user is logged in
if (!isset($_SESSION['student_id'])) {
    header("Location: index.php"); // Agar login nahi hai toh login page par bhej dein
    exit();
}

// Form submit hua hai ya nahi
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["assignmentFile"])) {
    
    $target_dir = "uploads/";
    $file_name = basename($_FILES["assignmentFile"]["name"]);
    $target_file = $target_dir . $file_name;

    // File ko "uploads" folder mein move karein
    if (move_uploaded_file($_FILES["assignmentFile"]["tmp_name"], $target_file)) {
        
        $student_id = $_SESSION['student_id'];
        $assignment_name = mysqli_real_escape_string($conn, $_POST['assignment_name']);
        $db_file_name = mysqli_real_escape_string($conn, $file_name);

        $sql = "INSERT INTO submitted_assignments (student_id, assignment_name, file_name) VALUES ('$student_id', '$assignment_name', '$db_file_name')";

        if (mysqli_query($conn, $sql)) {
            header("Location: student_dashboard.php?status=success");
        } else {
            header("Location: student_dashboard.php?status=error");
        }
    } else {
        header("Location: student_dashboard.php?status=error");
    }
}
mysqli_close($conn);
?>